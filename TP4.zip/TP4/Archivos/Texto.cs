﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        private string archivo;

        /// <summary>
        /// Constructor por defecto
        /// </summary>
        /// <param name="archivo"></param>
        public Texto(string archivo)
        {
            this.archivo = archivo;
        }

        /// <summary>
        /// Para guardar en .dat
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public bool guardar(string datos)
        {
            StreamWriter sw = File.AppendText(this.archivo);        
            bool value = false;

            try
            {
                if (!object.ReferenceEquals(sw, null) && datos != string.Empty && this.archivo != string.Empty)
                {
                    sw.WriteLine(datos);
                    value = true;
                }
                
            }
            catch (IOException ioException)
            {
                throw new ArchivosExceptions("No pudo abrirse el archivo. " + ioException.Message);
            }
            catch (Exception exception)
            {
                throw new ArchivosExceptions("No pudo abrirse el archivo. " + exception.Message);
            }
            finally
            {
                sw.Close();
            }

            return value;
        }

        /// <summary>
        /// Para leer en .dat
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public bool leer(out List<string> datos)
        {
            StreamReader sr = new StreamReader(archivo);
            bool value = false;
            datos = new List<string>();

            if (!object.ReferenceEquals(sr, null) && this.archivo != string.Empty)
            {
                while (!sr.EndOfStream)
                {
                    datos.Add(sr.ReadLine());
                    value = true;
                }
            }
            else
            {
                throw new ArchivosExceptions(new FileNotFoundException());
            }

            return value;
        }
    }
}
