﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net; // Avisar del espacio de nombre
using System.ComponentModel;

namespace Hilo
{
    public class Descargador
    {
        private string html;
        private Uri direccion;
        public delegate void ProgressChanged(int progreso);
        public event ProgressChanged progressChangedEvent;
        public delegate void DownloadComplete(string html);
        public event DownloadComplete downloadCompletedEvent;

        /// <summary>
        /// Constructor por defecto
        /// </summary>
        /// <param name="direccion"></param>
        public Descargador(Uri direccion)
        {
            this.direccion = direccion;
            this.html = "";
        }

        /// <summary>
        /// Para iniciar la descarga
        /// </summary>
        public void IniciarDescarga()
        {
            try
            {
                WebClient cliente = new WebClient();
                cliente.DownloadProgressChanged += WebClientDownloadProgressChanged; 
                cliente.DownloadStringCompleted += WebClientDownloadCompleted;

                cliente.DownloadStringAsync(this.direccion);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Para ver el progreso de la descarga
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WebClientDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            progressChangedEvent.Invoke(e.ProgressPercentage);
        }
        
        /// <summary>
        /// Para ver si se completo la descarga
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WebClientDownloadCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            try
            {
                this.html = e.Result;
                downloadCompletedEvent.Invoke(this.html);
            }
            catch
            {
                downloadCompletedEvent.Invoke("No se puede acceder a este sitio \nNo se encontró la dirección DNS " +
                    "del servidor de www.asdasdasdasd.");
            }
            
        }
    }
}
