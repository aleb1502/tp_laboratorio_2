﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesAbstractas
{
    public abstract class Universitario : Persona
    {
        private int legajo;

        /// <summary>
        /// Equaliza para saber si el objeto es una clase Universitario 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns> El booleano
        public override bool Equals(object obj)
        {
            bool value = false;

            if(obj is Universitario && this == (Universitario)obj)
            {
                value = true;
            }

            return value; 
        }

        /// <summary>
        /// Chequea el codigo
        /// </summary>
        /// <returns></returns> Un entero
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        /// <summary>
        /// Retorna los datos de Universitario
        /// </summary>
        /// <returns></returns> El StringBuilder
        protected virtual string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.ToString());
            sb.Append("LEGAJO NÚMERO: " + this.legajo);

            return sb.ToString();
        }

        /// <summary>
        /// Dos Universitario serán iguales si y sólo si son del mismo Tipo y su Legajo o DNI son iguales.
        /// </summary>
        /// <param name="pg1"></param>
        /// <param name="pg2"></param>
        /// <returns></returns> El booleano
        public static bool operator == (Universitario pg1, Universitario pg2)
        {
            bool value = false;

            if (!object.ReferenceEquals(pg1, null) && !object.ReferenceEquals(pg2, null))
            {
                if (pg1.GetType() == pg2.GetType() && (pg1.legajo == pg2.legajo || pg1.DNI == pg2.DNI))
                {
                    value = true;
                }
            }

            return value;
        }

        /// <summary>
        /// Opera el != del operador == (Universitario pg1, Universitario pg2)
        /// </summary>
        /// <param name="pg1"></param>
        /// <param name="pg2"></param>
        /// <returns></returns> El booleano
        public static bool operator != (Universitario pg1, Universitario pg2)
        {
            return !(pg1 == pg2);
        }

        /// <summary>
        /// Es una clase abstracta que se usa en las heredadas
        /// </summary>
        /// <returns></returns> Un string pero es abstracta
        protected abstract string ParticiparEnClase();

        /// <summary>
        /// Constructor por defecto que llama a la base
        /// </summary>
        public Universitario() : base()
        {
            
        }

        /// <summary>
        /// Constructor que recibe parametros y le asigna un legajo
        /// </summary>
        /// <param name="legajo"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(nombre, apellido,dni,nacionalidad)
        {
            this.legajo = legajo;
        }
    }
}
