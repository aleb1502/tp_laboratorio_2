﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;


namespace Clases_Instanciables
{
    public sealed class Alumno : Universitario
    {
        public enum EEstadoCuenta
        {
            Deudor,
            Becado,
            AlDia,
        }

        private Clases_Instanciables.Universidad.EClases _claseQueToma;
        private EEstadoCuenta _estadoCuenta;

        /// <summary>
        /// Constructor por defecto que llama a la base
        /// </summary>
        public Alumno() : base()
        {

        }

        /// <summary>
        /// Constructor por defecto que recibe parametros, llama a la base y le asigna la clase que toma
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        /// <param name="claseQueToma"></param>
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma)
            : base(id, nombre, apellido, dni, nacionalidad)
        {
            this._claseQueToma = claseQueToma;
        }

        /// <summary>
        /// Constructor por defecto que recibe parametros, llama a this y le asigna el estado de cuenta
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        /// <param name="claseQueToma"></param>
        /// <param name="estadoCuenta"></param>
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma, EEstadoCuenta estadoCuenta)
            : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
        {
            this._estadoCuenta = estadoCuenta;
        }

        /// <summary>
        /// Muestra los datos del alumno
        /// </summary>
        /// <returns></returns> El StringBuilder
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());

            if (this._estadoCuenta == EEstadoCuenta.AlDia)
            {
                sb.AppendLine("\nESTADO DE CUENTA: Cuota al día");
            }
            else
            {
                sb.AppendLine("\nESTADO DE CUENTA:" +  this._estadoCuenta);
            }
                
            sb.AppendLine(this.ParticiparEnClase());

            return sb.ToString();
        }

        /// <summary>
        /// Un Alumno será igual a un EClase si toma esa clase y su estado de cuenta no es Deudor.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="clase"></param>
        /// <returns></returns> El booleano
        public static bool operator == (Alumno a, Clases_Instanciables.Universidad.EClases clase)
        {
            bool value = false;

            if (!object.ReferenceEquals(a, null))
            {
                if (a._claseQueToma == clase && a._estadoCuenta != EEstadoCuenta.Deudor)
                {
                    value = true;
                }
            }

            return value;
        }

        /// <summary>
        /// Un Alumno será distinto a un EClase sólo si no toma esa clase.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="clase"></param>
        /// <returns></returns> El booleano
        public static bool operator != (Alumno a, Clases_Instanciables.Universidad.EClases clase)
        {
            bool value = false;

            if (!object.ReferenceEquals(a, null))
            {
                if (a._claseQueToma != clase)
                {
                    value = true;
                }
            }

            return value;
        }

        /// <summary>
        /// Equaliza para ver si el objeto es una clase de tipo Alumno
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns> El booleano
        public override bool Equals(object obj)
        {
            bool value = false;

            if (obj is Alumno && this == (Alumno)obj)
            {
                value = true;
            }

            return value;
        }

        /// <summary>
        /// Verifica el codigo
        /// </summary>
        /// <returns></returns> Un entero
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        /// <summary>
        /// Devuelve la clase que toma 
        /// </summary>
        /// <returns></returns> La clase
        protected override string ParticiparEnClase()
        {
            return string.Format("TOMA CLASE DE " + this._claseQueToma);
        }

        /// <summary>
        /// Reutiliza el MostrarDatos()
        /// </summary>
        /// <returns></returns> Los datos del alumno
        public override string ToString()
        {
            return this.MostrarDatos();
        }

    }
}
