﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;
using Clases_Instanciables;
namespace Clases_Instanciables
{
    public sealed class Profesor : Universitario
    {
        private Queue<Universidad.EClases> _clasesDelDia;
        private static Random _random;

        /// <summary>
        /// Le asigna dos clase del dia
        /// </summary>
        private void _randomClases()
        {
            for (int i = 0; i < 2; i++)
            {
                this._clasesDelDia.Enqueue((Universidad.EClases)Profesor._random.Next(0, 3));
            }
                
        }

        /// <summary>
        /// Muestra los datos del profesor
        /// </summary>
        /// <returns></returns> El StringBuilder
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine(this.ParticiparEnClase());
            return sb.ToString();
        }

        /// <summary>
        /// Un Profesor será igual a un EClase si da esa clase.
        /// </summary>
        /// <param name="i"></param>
        /// <param name="clase"></param>
        /// <returns></returns> El booleano
        public static bool operator == (Profesor i, Clases_Instanciables.Universidad.EClases clase)
        {
            bool value = false;

            if (!object.ReferenceEquals(i, null) && !object.ReferenceEquals(clase, null))
            {
                foreach (Universidad.EClases cl in i._clasesDelDia)
                {
                    if (cl == clase)
                    {
                        value = true;
                    }
                        
                }
            }

            return value;
        }

        /// <summary>
        /// Retorna el != del operador == (Profesor i, Clases_Instanciables.Universidad.EClases clase)
        /// </summary>
        /// <param name="i"></param>
        /// <param name="clase"></param>
        /// <returns></returns> El booleano
        public static bool operator != (Profesor i, Clases_Instanciables.Universidad.EClases clase)
        {
            return !(i == clase); 
        }

        /// <summary>
        /// Equaliza para ver si el objeto es una clase de tipo Profesor
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns> El booleano
        public override bool Equals(object obj)
        {
            bool value = false;

            if (obj is Profesor && this == (Profesor)obj)
            {
                value = true;
            }

            return value;
        }

        /// <summary>
        /// Verifica el codigo
        /// </summary>
        /// <returns></returns> Un entero
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        /// <summary>
        /// Devuelve las clase del dia
        /// </summary>
        /// <returns></returns> El StringBuilder
        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder("CLASES DEL DÍA:\n");

            if (!object.ReferenceEquals(this._clasesDelDia, null))
            {
                foreach (Universidad.EClases ec in this._clasesDelDia)
                {
                    sb.AppendFormat("{0}\n", ec);
                }
                    
            }

            return sb.ToString();
        }

        /// <summary>
        /// Constructor por defecto que inicializa el random
        /// </summary>
        static Profesor()
        {
            Profesor._random = new Random();
        }

        /// <summary>
        /// Constructor por defecto que llama a la base
        /// </summary>
        public Profesor() : base()
        {
            
        }

        /// <summary>
        /// En el constructor de instancia se inicializará ClasesDelDia y se asignarán dos clases al azar al Profesor mediante el método randomClases. Las dos clases pueden o no ser la misma.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            : base(id, nombre, apellido, dni, nacionalidad)
        {
            this._clasesDelDia = new Queue<Universidad.EClases>();
            this._randomClases();
        }


        /// <summary>
        /// Reutiliza el metodo MostrarDatos()
        /// </summary>
        /// <returns></returns> Los datos del profesor
        public override string ToString()
        {
            return this.MostrarDatos();
        }
    }
}
