﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;


namespace Clases_Instanciables
{
    [Serializable]
    public class Jornada
    {
        private List<Alumno> _alumnos;
        private Clases_Instanciables.Universidad.EClases _clases;
        private Profesor _instructor;

        public List<Alumno> Alumnos {

            get
            {
                return this._alumnos;
            }

            set
            {
                this._alumnos = value;
            }

        }

        public Clases_Instanciables.Universidad.EClases Clases {

            get
            {
                return this._clases;
            }

            set
            {
                this._clases = value;
            }

        }

        public Profesor Instructor {

            get
            {
                return this._instructor;
            }

            set
            {
                this._instructor = value;
            }

        }

        /// <summary>
        /// Guarda los datos del archivo
        /// </summary>
        /// <param name="jornada"></param>
        /// <returns></returns> El booleano
        public static bool Guardar(Jornada jornada)
        {
            Texto t1 = new Texto();
            bool value = false;

            if(t1.guardar("Jornada.txt", jornada.ToString()))
            {
                value = true;
            }

            return value;
        }

        /// <summary>
        /// Constructor por defecto que inicializa la lista de alumnos
        /// </summary>
        private Jornada()
        {
            this._alumnos = new List<Alumno>();
        }

        /// <summary>
        /// Constructor por defecto que reutiliza el anterior y le asigna la clase y el profesor
        /// </summary>
        /// <param name="clase"></param>
        /// <param name="instructor"></param>
        public Jornada(Clases_Instanciables.Universidad.EClases clase, Profesor instructor) : this()
        {
            this._clases = clase;
            this._instructor = instructor;
        }

        /// <summary>
        /// Lee el archivo de texto
        /// </summary>
        /// <returns></returns> Devuelve un string
        public string Leer()
        {
            Texto t1 = new Texto();
            string retorno = "\nEl archivo no pudo ser leido!\n";
            string dato = "";

            if(t1.leer("Jornada.txt", out retorno))
            {
                dato = retorno;
            }

            return dato;
            
        }

        /// <summary>
        /// Una Jornada será igual a un Alumno si el mismo participa de la clase.
        /// </summary>
        /// <param name="j"></param>
        /// <param name="a"></param>
        /// <returns></returns> Devuelve un booleano
        public static bool operator == (Jornada j, Alumno a)
        {
            bool value = false;

            if (!object.ReferenceEquals(j, null) && !object.ReferenceEquals(a, null))
            {
                foreach (Alumno al in j._alumnos)
                {
                    if (a == al)
                    {
                        value = true;
                    }
                }
            }

            return value;
        }

        /// <summary>
        /// El operador != al operador == (Jornada j, Alumno a)
        /// </summary>
        /// <param name="j"></param>
        /// <param name="a"></param>
        /// <returns></returns> Devuelve un booleano
        public static bool operator != (Jornada j, Alumno a)
        {
            return !(j == a);
        }

        /// <summary>
        /// Equaliza para ver si el objeto es de tipo Jornada
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns> Devuelve un booleano
        public override bool Equals(object obj)
        {
            bool value = false;

            if(obj is Jornada && this == (Jornada)obj)
            {
                value = true;
            }

            return value;
        }

        /// <summary>
        /// Verifica el codigo
        /// </summary>
        /// <returns></returns> Un entero
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        /// <summary>
        /// Agregar Alumnos a la clase por medio del operador +, validando que no estén previamente cargados.
        /// </summary>
        /// <param name="j"></param>
        /// <param name="a"></param>
        /// <returns></returns> Devuelve una Jornada
        public static Jornada operator + (Jornada j, Alumno a)
        {
            if (!object.ReferenceEquals(j, null) && !object.ReferenceEquals(a, null))
            {
                if (j == a)
                {
                    throw new AlumnoRepetidoException();
                }
                else
                {
                    j.Alumnos.Add(a);
                }

            }

            return j;
        }

        /// <summary>
        /// Retorna los datos de la jornada
        /// </summary>
        /// <returns></returns> Devuelve un StringBuilder
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("CLASE DE {0} POR {1}", this.Clases, this.Instructor.ToString());
            sb.AppendLine("ALUMNOS:");

            if(!object.ReferenceEquals(this._alumnos,null))
            {
                foreach (Alumno alumno in this.Alumnos)
                {
                    sb.AppendLine(alumno.ToString());
                }
            }

            return sb.ToString();
        }
    }
}
