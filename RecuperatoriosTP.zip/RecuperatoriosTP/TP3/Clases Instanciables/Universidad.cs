﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Excepciones;
using Archivos;
using System.Xml.Serialization;


namespace Clases_Instanciables
{
    [Serializable]
    public class Universidad
    {
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD,
        }

        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesores;

        public List<Alumno> Alumno {

            get
            {
                return this.alumnos;
            }
            
            set
            {
                this.alumnos = value;
            }

        }

        public List<Profesor> Instructores {

            get
            {
                return this.profesores;
            }

            set
            {
                this.profesores = value;
            }

        }

        public List<Jornada> Jornadas {

            get
            {
                return this.jornada;
            }

            set
            {
                this.jornada = value;
            }

        }

        public Jornada this[int i] {

            get
            {
                if (i >= 0 && i < this.Jornadas.Count)
                {
                    return this.Jornadas[i];
                }
                else
                {
                    throw new IndiceInvalidoException();
                }
                    
            }

            set
            {
                if (i >= 0 && i < this.Jornadas.Count)
                {
                    this.Jornadas[i] = value;
                }
                else if (i == this.Jornadas.Count)
                {
                    this.Jornadas.Add(value);
                }
                else
                {
                    throw new IndiceInvalidoException();
                }
                    
            }
        }

        /// <summary>
        /// Guarda los datos de la universidad
        /// </summary>
        /// <param name="gim"></param>
        /// <returns></returns> Devuelve un booleano
        public static bool Guardar(Universidad gim)
        {
            bool value = false;
            Xml<Universidad> xml = new Xml<Universidad>();

            if(xml.guardar("Universidad.xml", gim))
            {
                value = true;
            }

            return value;
        }

        /// <summary>
        /// Lee los datos de la universidad
        /// </summary>
        /// <param name="gim"></param>
        /// <returns></returns> Devuelve una Universidad
        public Universidad Leer(Universidad gim)
        {
            Xml<Universidad> xml = new Xml<Universidad>();
            xml.leer("Universidad.xml", out gim);

            return gim;
        }

        /// <summary>
        /// Retorna los datos de la universidad
        /// </summary>
        /// <param name="gim"></param>
        /// <returns></returns> El StringBuilder
        private static string MostrarDatos(Universidad gim)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("JORNADA:");

            if (!object.ReferenceEquals(gim.Jornadas, null))
            {
                foreach (Jornada jor in gim.Jornadas)
                {
                    sb.AppendLine(jor.ToString());
                    sb.AppendLine("< ---------------------------------------------------------------->");
                }
            }

            return sb.ToString();
        }

        /// <summary>
        /// Equaliza para ver si el objeto es de tipo Universidad
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns> Devuelve un booleano
        public override bool Equals(object obj)
        {
            bool value = false;

            if (obj is Universidad && this == (Universidad)obj)
            {
                value = true;
            }

            return value;
        }

        /// <summary>
        /// Verifica el codigo
        /// </summary>
        /// <returns></returns> Devuelve un entero
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        /// <summary>
        /// Una Universidad será igual a un Alumno si el mismo está inscripto en él.
        /// </summary>
        /// <param name="g"></param>
        /// <param name="a"></param>
        /// <returns></returns> Devuelve un booleano
        public static bool operator == (Universidad g, Alumno a)
        {
            bool value = false;

            if (!object.ReferenceEquals(g, null) && !object.ReferenceEquals(a, null))
            {
                foreach (Alumno al in g.alumnos)
                {
                    if (a == al)
                    {
                        value = true;
                    }
                }
            }

            return value;
        }

        /// <summary>
        /// El operador != del operador == (Universidad g, Alumno a)
        /// </summary>
        /// <param name="g"></param>
        /// <param name="a"></param>
        /// <returns></returns> Devuelve un booleano
        public static bool operator != (Universidad g, Alumno a)
        {
            return !(g == a);
        }

        /// <summary>
        /// Se agregarán Alumnos mediante el operador +, validando que no estén previamente cargados.
        /// </summary>
        /// <param name="g"></param>
        /// <param name="a"></param>
        /// <returns></returns> Devuelve una Universidad
        public static Universidad operator + (Universidad g, Alumno a)
        {
            if (!object.ReferenceEquals(g, null) && !object.ReferenceEquals(a, null))
            {
                if (g == a)
                {
                    throw new AlumnoRepetidoException();
                }
                else
                {
                    g.alumnos.Add(a);
                }
            }
                
            return g;
        }

        /// <summary>
        /// Un Universidad será igual a un Profesor si el mismo está dando clases en él.
        /// </summary>
        /// <param name="g"></param>
        /// <param name="i"></param>
        /// <returns></returns> Devuelve un booleano
        public static bool operator == (Universidad g, Profesor i)
        {
            bool value = false;

            if (!object.ReferenceEquals(g, null) && !object.ReferenceEquals(i, null))
            {
                foreach (Profesor prof in g.profesores)
                {
                    if (i == prof)
                    {
                        value = true;
                    }
                }
            }

            return value;
        }

        /// <summary>
        /// El operador != al operador == (Universidad g, Profesor i)
        /// </summary>
        /// <param name="g"></param>
        /// <param name="i"></param>
        /// <returns></returns> Devuelve un booleano
        public static bool operator != (Universidad g, Profesor i)
        {
            return !(g == i);
        }

        /// <summary>
        /// Se agregarán Profesores mediante el operador +, validando que no estén previamente cargados.
        /// </summary>
        /// <param name="g"></param>
        /// <param name="i"></param>
        /// <returns></returns> Devuelve una Universidad
        public static Universidad operator + (Universidad g, Profesor i)
        {
            if (!object.ReferenceEquals(g, null) && !object.ReferenceEquals(i, null))
            {
                if (g == i)
                {
                    throw new ProfesorRepetidoException();
                }
                else
                {
                    g.profesores.Add(i);
                }
            }
               
            return g;
        }

        /// <summary>
        /// La igualación entre un Universidad y una Clase retornará el primer Profesor capaz de dar esa clase.
        /// Sino, lanzará la Excepción SinProfesorException.
        /// </summary>
        /// <param name="g"></param>
        /// <param name="clase"></param>
        /// <returns></returns> Devuelve un Profesor
        public static Profesor operator == (Universidad g, EClases clase)
        {
            if (!object.ReferenceEquals(g, null) && !object.ReferenceEquals(g.profesores,null))
            {
                foreach (Profesor prof in g.profesores)
                {
                    if (prof == clase)
                        return prof; // Si p == clase (el profesor da esa clase) lo retorna (primero que encuentra)
                }
            }

            throw new SinProfesorException();
        }

        /// <summary>
        /// El distinto retornará el primer Profesor que no pueda dar la clase.
        /// </summary>
        /// <param name="g"></param>
        /// <param name="clase"></param>
        /// <returns></returns> Devuelve un Profesor
        public static Profesor operator != (Universidad g, EClases clase)
        {
            if (!object.ReferenceEquals(g, null) && !object.ReferenceEquals(g.profesores, null))
            {
                foreach (Profesor prof in g.profesores)
                {
                    if (prof != clase)
                        return prof; // Si p != clase (el profesor NO da esa clase) lo retorna (primero que encuentra)
                }
            }

            throw new SinProfesorException();
        }

        /// <summary>
        /// Al agregar una clase a un Universidad se deberá generar y agregar una nueva Jornada indicando la clase, 
        /// un Profesor que pueda darla (según su atributo ClasesDelDia) 
        /// y la lista de alumnos que la toman (todos los que coincidan en su campo ClaseQueToma).
        /// </summary>
        /// <param name="g"></param>
        /// <param name="clase"></param>
        /// <returns></returns> Devuelve una Universidad
        public static Universidad operator + (Universidad g, EClases clase)
        {
            if (!object.ReferenceEquals(g, null) && !object.ReferenceEquals(g.alumnos, null))
            {
                Jornada jor = new Jornada(clase, g == clase);

                foreach (Alumno alumno in g.alumnos)
                {
                    if (alumno == clase) // acá evaluo los alumnos que toman esa clase para agregarlos (en caso afirmativo) a la jornada
                    {
                        jor+= alumno;
                    }
                }

                g.Jornadas.Add(jor);
            }

            return g;
        }

        /// <summary>
        /// Reutiliza el metodo MostrarDatos();
        /// </summary>
        /// <returns></returns> Devuelve un string
        public override string ToString()
        {
            return MostrarDatos(this);
        }

        /// <summary>
        /// Constructor por defecto que inicializa las listas
        /// </summary>
        public Universidad()
        {
            this.alumnos = new List<Alumno>();
            this.jornada = new List<Jornada>();
            this.profesores = new List<Profesor>();
        }
    }
}
