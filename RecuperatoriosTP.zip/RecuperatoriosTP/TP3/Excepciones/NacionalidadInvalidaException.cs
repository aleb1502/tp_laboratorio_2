﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class NacionalidadInvalidaException : Exception
    {
        /// <summary>
        /// Lanza el mensaje "La nacionalidad no se condice con el número de DNI."
        /// </summary>
        public NacionalidadInvalidaException()
            : base("La nacionalidad no se condice con el número de DNI.")
        {

        }

        /// <summary>
        /// Recibe un mensaje y llama a la base
        /// </summary>
        /// <param name="mesagge"></param>
        public NacionalidadInvalidaException(string mesagge)
            : base(mesagge)
        {
            
        }
    }
}
