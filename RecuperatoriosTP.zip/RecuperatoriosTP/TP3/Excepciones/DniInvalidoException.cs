﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class DniInvalidoException : Exception
    {
        private static string mensajeBase = "El DNI ingresado no es un número válido.";

        /// <summary>
        /// Llama a la base que recibe el mensaje base
        /// </summary>
        public DniInvalidoException() : base(mensajeBase)
        {

        }

        /// <summary>
        /// Llama a la base que recibe dos parametros, incluyendo el mensaje base
        /// </summary>
        /// <param name="e"></param>
        public DniInvalidoException(Exception e) : base(mensajeBase, e)
        {

        }

        /// <summary>
        /// Llama a la base que recibe dos parametros, incluyendo el mensaje
        /// </summary>
        /// <param name="message"></param>
        /// <param name="e"></param>
        public DniInvalidoException(string message, Exception e) : base(message, e)
        {

        }

        /// <summary>
        /// Llama a la base que recibe el mensaje
        /// </summary>
        /// <param name="message"></param>
        public DniInvalidoException(string message) : base(message)
        {

        }
    }
}
