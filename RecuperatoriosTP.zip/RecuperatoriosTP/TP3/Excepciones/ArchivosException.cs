﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class ArchivosException : Exception
    {
        /// <summary>
        /// Llama a this()
        /// </summary>
        public ArchivosException() : this(null)
        {

        }

        /// <summary>
        /// Lanza el mensaje "Error de Archivo"
        /// </summary>
        /// <param name="innerException"></param>
        public ArchivosException(Exception innerException) : base("Error de Archivo", innerException)
        {

        }
    }
}
